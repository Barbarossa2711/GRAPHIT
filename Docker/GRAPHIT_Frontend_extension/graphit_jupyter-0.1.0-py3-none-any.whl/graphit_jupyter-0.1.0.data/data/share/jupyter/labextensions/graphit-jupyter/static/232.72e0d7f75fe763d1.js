"use strict";(self.rspackChunkgraphit_jupyter=self.rspackChunkgraphit_jupyter||[]).push([[232],{475(r,a,t){var o=t(601),e=t.n(o),i=t(314),p=t.n(i),n=t(554),l=t(884),s=t(342),d=t(287),g=t(743),h=t(382),c=p()(e());c.i(n.A),c.i(l.A),c.i(s.A),c.i(d.A),c.i(g.A),c.i(h.A),c.push([r.id,`/*
 * GRAPHIT base styles.
 *
 * No hardcoded colours: everything resolves to JupyterLab CSS variables, so light and
 * dark themes work without theme detection.
 */

.graphit-root {
  /* Semantic layer: status colours live here and nowhere else. */
  --graphit-status-new: var(--jp-ui-font-color3);
  --graphit-status-visited: var(--jp-info-color1);
  --graphit-status-inprogress: var(--jp-warn-color1);
  --graphit-status-due: var(--jp-brand-color1);
  --graphit-status-mastered: var(--jp-success-color1);

  --graphit-gap: 8px;
  --graphit-radius: 4px;

  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  box-sizing: border-box;
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color1);
  font-family: var(--jp-ui-font-family);
  font-size: var(--jp-ui-font-size1);
}

.graphit-root *,
.graphit-root *::before,
.graphit-root *::after {
  box-sizing: inherit;
}

/* ---------- generic building blocks ---------- */

.graphit-pill {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 0 6px;
  height: 18px;
  border-radius: 9px;
  font-size: var(--jp-ui-font-size0);
  line-height: 1;
  white-space: nowrap;
  border: 1px solid var(--jp-border-color2);
  color: var(--jp-ui-font-color2);
}

.graphit-pill[data-status='new'] {
  border-color: var(--graphit-status-new);
}

.graphit-pill[data-status='visited'] {
  border-color: var(--graphit-status-visited);
  color: var(--graphit-status-visited);
}

.graphit-pill[data-status='in_progress'] {
  border-color: var(--graphit-status-inprogress);
  color: var(--graphit-status-inprogress);
}

.graphit-pill[data-status='due_review'] {
  border-color: var(--graphit-status-due);
  color: var(--graphit-status-due);
}

.graphit-pill[data-status='mastered'] {
  border-color: var(--graphit-status-mastered);
  color: var(--graphit-status-mastered);
}

.graphit-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex: 0 0 auto;
  background: var(--graphit-status-new);
}

.graphit-dot[data-status='visited'] {
  background: var(--graphit-status-visited);
}

.graphit-dot[data-status='in_progress'] {
  background: var(--graphit-status-inprogress);
}

.graphit-dot[data-status='due_review'] {
  background: var(--graphit-status-due);
}

.graphit-dot[data-status='mastered'] {
  background: var(--graphit-status-mastered);
}

.graphit-bar {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--jp-layout-color3);
  overflow: hidden;
}

.graphit-bar-fill {
  position: absolute;
  inset: 0 auto 0 0;
  background: var(--jp-brand-color1);
}

.graphit-bar-peak {
  position: absolute;
  top: -2px;
  bottom: -2px;
  width: 2px;
  background: var(--jp-ui-font-color2);
}

/* Mastery threshold marker on the same 0–100 % scale as the fill. */
.graphit-bar-threshold {
  position: absolute;
  top: -2px;
  bottom: -2px;
  width: 2px;
  margin-left: -1px;
  background: var(--graphit-status-mastered);
}

/* Captioned variant: peak marker above the bar, threshold below. */
.graphit-bar-labeled {
  position: relative;
  margin-top: 12px;
  margin-bottom: 44px;
}

/* Reserve room above the bar only when the peak caption is shown. */
.graphit-bar-labeled[data-peak='true'] {
  margin-top: 44px;
}

.graphit-bar-marker {
  position: absolute;
  top: 0;
  width: 0;
}

.graphit-bar-marker-line {
  position: absolute;
  left: 0;
  width: 2px;
  height: 18px;
  transform: translateX(-1px);
  border-radius: 1px;
}

.graphit-bar-marker[data-placement='below'] .graphit-bar-marker-line {
  top: -4px;
}

.graphit-bar-marker[data-placement='above'] .graphit-bar-marker-line {
  top: -12px;
}

.graphit-bar-marker--threshold[data-placement='below']
  .graphit-bar-marker-line {
  top: 0;
  height: 14px;
  background: var(--jp-ui-font-color0);
}

.graphit-bar-marker--peak .graphit-bar-marker-line {
  background: var(--jp-ui-font-color2);
}

/* Subtle 0 % / 100 % scale ends, symmetric around the bar. */
.graphit-bar-marker--scale .graphit-bar-marker-line {
  top: -4px;
  height: 14px;
  background: var(--jp-border-color1);
}

.graphit-bar-marker--scale .graphit-bar-marker-label {
  color: var(--jp-ui-font-color3);
}

.graphit-bar-marker--scale .graphit-bar-marker-label b {
  font-weight: 400;
}

.graphit-bar-marker-label {
  position: absolute;
  left: 0;
  display: flex;
  flex-direction: column;
  line-height: 1.2;
  font-size: var(--jp-ui-font-size0);
  white-space: nowrap;
}

.graphit-bar-marker[data-placement='below'] .graphit-bar-marker-label {
  top: 16px;
}

.graphit-bar-marker[data-placement='above'] .graphit-bar-marker-label {
  bottom: 14px;
}

.graphit-bar-marker-label b {
  font-weight: 600;
}

/* Only achievement fills this bar; the empty track is everything not yet mastered. */
.graphit-achieve {
  display: flex;
  height: 6px;
  border-radius: 3px;
  overflow: hidden;
  background: var(--jp-layout-color3);
}

.graphit-achieve > span {
  display: block;
  height: 100%;
}

.graphit-achieve-mastered {
  background: var(--graphit-status-mastered);
}

/*
 * Due concepts: faded "mastered" hue (achieved work that decayed); the stripes keep it
 * distinguishable without colour.
 */
.graphit-achieve-due {
  background: repeating-linear-gradient(
    45deg,
    var(--graphit-status-mastered) 0,
    var(--graphit-status-mastered) 2px,
    transparent 2px,
    transparent 4px
  );
  opacity: 0.75;
}

/*
 * Status distribution bar: always sums to 100 %, so it has hard segment edges for
 * comparing proportions.
 */
.graphit-dist {
  display: flex;
  height: 10px;
  border-radius: 3px;
  overflow: hidden;
  background: var(--jp-layout-color3);
}

.graphit-dist-seg {
  display: block;
  height: 100%;
  /* Hairline separators keep adjacent segments countable. */
  box-shadow: inset -1px 0 0 var(--jp-layout-color1);
}

.graphit-dist-seg:last-child {
  box-shadow: none;
}

/* Same light grey as the empty achievement track: "nothing happened yet". */
.graphit-dist-seg[data-status='new'] {
  background: var(--jp-layout-color3);
}

.graphit-dist-seg[data-status='visited'] {
  background: var(--graphit-status-visited);
}

.graphit-dist-seg[data-status='in_progress'] {
  background: var(--graphit-status-inprogress);
}

.graphit-dist-seg[data-status='due_review'] {
  background: var(--graphit-status-due);
}

.graphit-dist-seg[data-status='mastered'] {
  background: var(--graphit-status-mastered);
}

/* Legend swatches for the achievement bar. */
.graphit-achieve-key {
  display: inline-block;
  width: 14px;
  height: 8px;
  border-radius: 2px;
}

.graphit-muted {
  color: var(--jp-ui-font-color3);
}

.graphit-small {
  font-size: var(--jp-ui-font-size0);
}

.graphit-error {
  border: 1px solid var(--jp-error-color1);
  border-left-width: 3px;
  border-radius: var(--graphit-radius);
  padding: 8px 10px;
  margin: 8px 0;
  background: var(--jp-layout-color2);
}

.graphit-error-title {
  font-weight: 600;
  color: var(--jp-error-color1);
}

.graphit-notice {
  border: 1px solid var(--jp-border-color2);
  border-left: 3px solid var(--jp-brand-color1);
  border-radius: var(--graphit-radius);
  padding: 8px 10px;
  margin: 8px 0;
  background: var(--jp-layout-color2);
}

/* The left rule carries the tone; "due" must not look like an error. */
.graphit-notice[data-tone='blocked'] {
  border-left-color: var(--graphit-status-inprogress);
}

.graphit-notice[data-tone='due'] {
  border-left-color: var(--graphit-status-due);
}

.graphit-notice[data-tone='ready'] {
  border-left-color: var(--graphit-status-mastered);
}

/* Armed state of the two-step "Konzept abfragen" button. */
.graphit-notice[data-armed='true'] {
  border-color: var(--jp-warn-color1);
  background: color-mix(in srgb, var(--jp-warn-color1) 12%, var(--jp-layout-color1));
}

/* Button styled as an inline link (in-panel navigation, keyboard-reachable). */
.graphit-linklike {
  display: inline;
  padding: 0;
  border: none;
  background: none;
  color: var(--jp-brand-color1);
  font: inherit;
  cursor: pointer;
  text-decoration: underline;
}

.graphit-linklike:hover {
  color: var(--jp-brand-color0);
}

.graphit-linklike:disabled {
  color: var(--jp-ui-font-color3);
  cursor: default;
  text-decoration: none;
}

.graphit-linklike:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: 2px;
}

/* Logged-in identity (read-only). */
.graphit-identity {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  text-align: center;
}

/* Connection dot and name on one line. */
.graphit-identity-value {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.graphit-identity-name {
  font-size: var(--jp-ui-font-size1);
  padding: 1px 6px;
  border-radius: var(--graphit-radius);
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.graphit-identity-missing {
  color: var(--jp-warn-color1);
  font-size: var(--jp-ui-font-size1);
}

.graphit-empty {
  padding: 24px 16px;
  text-align: center;
  color: var(--jp-ui-font-color3);
}

.graphit-spinner {
  display: inline-block;
  width: 14px;
  height: 14px;
  border: 2px solid var(--jp-border-color1);
  border-top-color: var(--jp-brand-color1);
  border-radius: 50%;
  animation: graphit-spin 0.8s linear infinite;
  vertical-align: -2px;
}

@keyframes graphit-spin {
  to {
    transform: rotate(360deg);
  }
}

@media (prefers-reduced-motion: reduce) {
  .graphit-spinner {
    animation-duration: 3s;
  }
}
`,""]),t.d(a,{},{A:c})},342(r,a,t){var o=t(601),e=t.n(o),i=t(314),p=(t.n(i))()(e());p.push([r.id,`/* Chat widget. */

.graphit-chat {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.graphit-chat-scope {
  display: flex;
  align-items: center;
  gap: var(--graphit-gap);
  padding: 6px 10px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
  flex-wrap: wrap;
  flex: 0 0 auto;
}

.graphit-chat-scope-label {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--jp-ui-font-size1);
}

.graphit-chat-scope-label b {
  font-weight: 600;
}

.graphit-messages {
  flex: 1 1 auto;
  min-height: 0;
  overflow: auto;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.graphit-msg {
  max-width: 92%;
  padding: 8px 10px;
  border-radius: var(--graphit-radius);
  font-family: var(--jp-content-font-family);
  font-size: var(--jp-content-font-size1);
  line-height: 1.5;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.graphit-msg[data-role='user'] {
  align-self: flex-end;
  background: var(--jp-brand-color1);
  color: var(--jp-layout-color1);
}

.graphit-msg[data-role='assistant'] {
  align-self: flex-start;
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
}

.graphit-msg code {
  font-family: var(--jp-code-font-family);
  font-size: 0.92em;
  background: var(--jp-cell-editor-background, var(--jp-layout-color3));
  padding: 1px 4px;
  border-radius: 3px;
}

.graphit-msg pre {
  font-family: var(--jp-code-font-family);
  font-size: 0.92em;
  background: var(--jp-cell-editor-background, var(--jp-layout-color3));
  padding: 8px;
  border-radius: var(--graphit-radius);
  overflow-x: auto;
  margin: 6px 0;
}

.graphit-msg-aborted {
  display: block;
  margin-top: 4px;
  font-size: var(--jp-ui-font-size0);
  font-style: italic;
  color: var(--jp-ui-font-color3);
}

.graphit-thinking {
  align-self: flex-start;
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size1);
  padding: 8px 10px;
}

.graphit-composer {
  flex: 0 0 auto;
  border-top: 1px solid var(--jp-border-color2);
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.graphit-composer textarea {
  resize: vertical;
  min-height: 54px;
  max-height: 200px;
  width: 100%;
  font-family: var(--jp-ui-font-family);
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--graphit-radius);
  padding: 6px 8px;
}

.graphit-composer textarea:focus {
  outline: 1px solid var(--jp-brand-color1);
  outline-offset: -1px;
}

.graphit-composer-row {
  display: flex;
  align-items: center;
  gap: var(--graphit-gap);
  flex-wrap: wrap;
}

.graphit-composer-hint {
  flex: 1 1 auto;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
}

/* Concept link in a tutor answer; a button that selects the concept. */
.graphit-concept-link {
  padding: 0;
  border: none;
  background: none;
  color: var(--jp-brand-color1);
  font: inherit;
  cursor: pointer;
  text-decoration: underline;
}

.graphit-concept-link:hover {
  color: var(--jp-brand-color0);
}

.graphit-concept-link:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: 2px;
}

/* Collapsible list of the slides used for an answer, deliberately small and grey. */
.graphit-sources {
  margin-top: 8px;
  border-top: 1px solid var(--jp-border-color2);
  padding-top: 6px;
  /* The bubble uses pre-wrap; the list is markup and must not. */
  white-space: normal;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
}

.graphit-sources > summary {
  cursor: pointer;
  list-style: none;
  user-select: none;
}

/* Custom triangle, since the native marker is spaced differently across browsers. */
.graphit-sources > summary::-webkit-details-marker {
  display: none;
}

.graphit-sources > summary::before {
  content: '▸';
  display: inline-block;
  width: 1em;
}

.graphit-sources[open] > summary::before {
  content: '▾';
}

.graphit-sources > summary:hover {
  color: var(--jp-ui-font-color2);
}

.graphit-sources ul {
  margin: 4px 0 0;
  padding-left: 1em;
  list-style: none;
}

.graphit-sources li {
  padding: 1px 0;
  line-height: 1.4;
  /* Prevents long file names from widening the bubble. */
  overflow-wrap: anywhere;
}

.graphit-sources-slide {
  font-weight: 600;
  color: var(--jp-ui-font-color2);
}
`,""]),t.d(a,{},{A:p})},554(r,a,t){var o=t(601),e=t.n(o),i=t(314),p=(t.n(i))()(e());p.push([r.id,`/* Main widget shell, sidebar, tab bar. */

.graphit-tabs {
  display: flex;
  align-items: stretch;
  gap: 0;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
  flex: 0 0 auto;
}

.graphit-tab {
  appearance: none;
  border: none;
  background: transparent;
  color: var(--jp-ui-font-color2);
  font-family: inherit;
  font-size: var(--jp-ui-font-size1);
  padding: 8px 14px;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  display: flex;
  align-items: center;
  gap: 6px;
}

.graphit-tab:hover {
  background: var(--jp-layout-color1);
}

.graphit-tab[aria-selected='true'] {
  color: var(--jp-ui-font-color1);
  border-bottom-color: var(--jp-brand-color1);
  background: var(--jp-layout-color1);
}

.graphit-tab-badge {
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 9px;
  background: var(--jp-brand-color1);
  color: var(--jp-layout-color1);
  font-size: var(--jp-ui-font-size0);
  line-height: 18px;
  text-align: center;
}

.graphit-body {
  flex: 1 1 auto;
  min-height: 0;
  overflow: hidden;
  display: flex;
}

.graphit-scroll {
  flex: 1 1 auto;
  min-height: 0;
  overflow: auto;
  padding: 12px 16px;
}

/* Concepts tab: overview above, two-column split below. */
/* min-height: 0 so the tree can scroll inside its own box. */
.graphit-concepts {
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  min-height: 0;
  width: 100%;
}

.graphit-overview {
  flex: 0 0 auto;
  padding: 8px 12px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
}

.graphit-overview-head {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin-bottom: 6px;
}

.graphit-overview-title {
  font-weight: 600;
}

.graphit-overview-main {
  font-size: var(--jp-ui-font-size2);
}

.graphit-overview-legend {
  margin-top: 8px;
}

.graphit-overview-legend > summary {
  cursor: pointer;
  color: var(--jp-ui-font-color2);
}

/* Explicit line-height so each dt is exactly one line tall. */
.graphit-overview-legend .graphit-facts {
  line-height: 1.5;
  align-items: start;
}

/*
 * Legend terms are symbols: no wrapping, and each dt is one line tall so symbols align
 * with the first line of their description.
 */
.graphit-overview-legend .graphit-facts > dt {
  min-width: 90px;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 1.5em;
}

.graphit-overview-legend .graphit-bar,
.graphit-overview-legend .graphit-achieve {
  width: 70px;
  flex: 0 0 auto;
}

.graphit-split {
  display: flex;
  flex: 1 1 auto;
  min-height: 0;
  width: 100%;
}

/* Width from --graphit-split-left (set in App.tsx); fixed basis, no growing. */
.graphit-split-left {
  flex: 0 0 var(--graphit-split-left, 45%);
  min-width: 260px;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

.graphit-split-right {
  flex: 1 1 auto;
  min-width: 260px;
  min-height: 0;
  overflow: auto;
}

/* Divider: a 2px line inside a wider hit area. */
.graphit-splitter {
  flex: 0 0 7px;
  position: relative;
  cursor: col-resize;
  background: var(--jp-border-color2);
  background-clip: content-box;
  border-left: 3px solid transparent;
  border-right: 3px solid transparent;
  touch-action: none;
}

.graphit-splitter:hover,
.graphit-splitter:focus-visible,
.graphit-splitter[data-dragging='true'] {
  background-color: var(--jp-brand-color1);
  outline: none;
}

/* Prevents text selection while dragging. */
.graphit-splitter[data-dragging='true']::after {
  content: '';
  position: fixed;
  inset: 0;
  cursor: col-resize;
  z-index: 10;
}

@media (width <= 800px) {
  .graphit-split {
    flex-direction: column;
  }

  /* Stacked layout: divider hidden, fixed halves. */
  .graphit-splitter {
    display: none;
  }

  .graphit-split-left {
    border-bottom: 1px solid var(--jp-border-color2);
    flex: 0 0 50%;
  }
}

.graphit-tree-title {
  margin: 0;
  padding: 8px 8px 4px;
  flex: 0 0 auto;
}

.graphit-guide {
  max-width: 720px;
  padding: 12px 16px 24px;
  line-height: 1.5;
}

.graphit-guide h3 {
  margin: 20px 0 6px;
}

.graphit-guide-list dt {
  font-weight: 600;
  margin-top: 10px;
}

.graphit-guide-list dd {
  margin: 2px 0 0;
  color: var(--jp-ui-font-color2);
}

/* Tab overview as cards */
.graphit-guide-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 12px;
  margin-top: 8px;
}

.graphit-guide-card {
  padding: 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 8px;
  background: var(--jp-layout-color2);
}

.graphit-guide-card-icon {
  font-size: 22px;
  line-height: 1;
}

.graphit-guide-card h4 {
  margin: 6px 0 4px;
}

.graphit-guide-card p {
  margin: 0;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

/* Numbered steps with a badge */
.graphit-guide-steps {
  list-style: none;
  margin: 8px 0 0;
  padding: 0;
}

.graphit-guide-steps li {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 10px;
}

.graphit-guide-step-num {
  flex: 0 0 auto;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  color: var(--jp-ui-inverse-font-color1, var(--jp-layout-color1));
  background: var(--jp-brand-color1);
}

/* Live mastery-bar example */
.graphit-guide-example {
  margin: 10px 0 4px;
  padding: 12px 16px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 8px;
  background: var(--jp-layout-color1);
}

/* Status list: pill + label on the left, longer explanation on the right */
.graphit-guide-status {
  margin: 8px 0 0;
}

.graphit-guide-status-row {
  display: grid;
  grid-template-columns: 130px 1fr;
  gap: 8px 16px;
  padding: 8px 0;
  border-top: 1px solid var(--jp-border-color2);
}

.graphit-guide-status-row:first-child {
  border-top: none;
}

.graphit-guide-status dt {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}

.graphit-guide-status dd {
  margin: 0;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

@media (max-width: 520px) {
  .graphit-guide-status-row {
    grid-template-columns: 1fr;
    gap: 4px;
  }
}

.graphit-toolbar {
  display: flex;
  align-items: center;
  gap: var(--graphit-gap);
  padding: 6px 8px;
  border-bottom: 1px solid var(--jp-border-color2);
  flex: 0 0 auto;
  flex-wrap: wrap;
}

.graphit-toolbar input[type='search'],
.graphit-toolbar input[type='text'] {
  flex: 1 1 120px;
  min-width: 80px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--graphit-radius);
  padding: 3px 6px;
  font-family: inherit;
  font-size: var(--jp-ui-font-size1);
}

.graphit-section {
  margin-bottom: 20px;
}

.graphit-section > h3 {
  margin: 0 0 8px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

/* Collapsible section: the h3 inside the summary repeats the section heading style. */
.graphit-collapse > summary {
  cursor: pointer;
  margin-bottom: 8px;
}

.graphit-collapse > summary > h3 {
  display: inline;
  margin: 0;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.graphit-collapse > summary:hover > h3 {
  color: var(--jp-brand-color1);
}

/* flow-root keeps the bar captions inside this block (e.g. for the tour ring). */
.graphit-mastery {
  display: flow-root;
}

.graphit-section > h4 {
  margin: 12px 0 6px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
}

/* ---------- left sidebar ---------- */

.graphit-sidebar {
  /* No bottom padding; the identity block sticks to the lower edge. */
  padding: 10px 12px 0;
  overflow: auto;
  gap: 12px;
}

/*
 * Identity footer: pushed down by margin-top: auto and kept visible with sticky. The
 * wrapper sticks (not the card) so its opaque padding hides scrolling content.
 */
.graphit-sidebar-footer {
  position: sticky;
  bottom: 0;
  margin-top: auto;
  padding-bottom: 10px;
  background: var(--jp-layout-color1);
}

/* More compact than a regular block. */
.graphit-sidebar-identity {
  padding: 7px 10px;
}

.graphit-sidebar h2 {
  margin: 0;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  letter-spacing: 0.04em;
}

/* Acronym expansion below the name. */
.graphit-sidebar-subtitle {
  margin: -2px 0 8px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

/* Acronym explanation in the guide: term left, meaning right, two rows. */
.graphit-guide-acronym {
  display: grid;
  grid-template-columns: max-content 1fr;
  gap: 4px 12px;
  margin: 6px 0 14px;
}

.graphit-guide-acronym dt {
  font-weight: 600;
}

.graphit-guide-acronym dd {
  margin: 0;
  color: var(--jp-ui-font-color2);
}

.graphit-sidebar-block {
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius);
  padding: 10px;
  background: var(--jp-layout-color2);
}

/* Heading of a sidebar block. */
.graphit-sidebar-title {
  font-weight: 600;
  margin-bottom: 6px;
}

/* ---------- activity heatmap ---------- */

/* Fixed height, so the grid does not move when the hover text changes. */
.graphit-heatmap-head {
  margin-bottom: 6px;
  min-height: 18px;
}

.graphit-heatmap-hover {
  color: var(--jp-ui-font-color1);
}

/* Scales with the panel width, keeping its aspect ratio. */
.graphit-heatmap-grid {
  display: block;
  width: 100%;
  height: auto;
}

.graphit-heatmap-cell {
  cursor: default;
  /* Five levels as opacity steps of the mastered colour (one hue, theme-aware). */
  fill: var(--jp-layout-color3);
}

.graphit-heatmap-cell[data-level='1'] {
  fill: color-mix(in srgb, var(--graphit-status-mastered) 30%, transparent);
}

.graphit-heatmap-cell[data-level='2'] {
  fill: color-mix(in srgb, var(--graphit-status-mastered) 55%, transparent);
}

.graphit-heatmap-cell[data-level='3'] {
  fill: color-mix(in srgb, var(--graphit-status-mastered) 78%, transparent);
}

.graphit-heatmap-cell[data-level='4'] {
  fill: var(--graphit-status-mastered);
}

/* Hover outline instead of recolouring; after the level rules so it always wins. */
.graphit-heatmap-cell[data-hovered='true'] {
  stroke: var(--jp-ui-font-color1);
  stroke-width: 1.5;
}

/* Future days, drawn faintly. */
.graphit-heatmap-cell[data-level='future'] {
  fill: var(--jp-layout-color2);
  stroke: var(--jp-layout-color3);
  stroke-width: 1;
}

.graphit-heatmap-month {
  font-size: 9px;
  fill: var(--jp-ui-font-color3);
}

.graphit-heatmap-legend {
  display: flex;
  align-items: center;
  gap: 3px;
  margin-top: 6px;
}

.graphit-heatmap-key {
  width: 10px;
  height: 10px;
  border-radius: 2px;
  background: var(--jp-layout-color3);
}

.graphit-heatmap-key[data-level='1'] {
  background: color-mix(
    in srgb,
    var(--graphit-status-mastered) 30%,
    transparent
  );
}

.graphit-heatmap-key[data-level='2'] {
  background: color-mix(
    in srgb,
    var(--graphit-status-mastered) 55%,
    transparent
  );
}

.graphit-heatmap-key[data-level='3'] {
  background: color-mix(
    in srgb,
    var(--graphit-status-mastered) 78%,
    transparent
  );
}

.graphit-heatmap-key[data-level='4'] {
  background: var(--graphit-status-mastered);
}

.graphit-sidebar-due {
  text-align: center;
}

.graphit-bignum {
  font-size: 34px;
  line-height: 1.1;
  font-weight: 600;
  color: var(--graphit-status-due);
}

.graphit-bignum[data-zero='true'] {
  color: var(--jp-ui-font-color3);
}

.graphit-sidebar-actions {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.graphit-conn {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.graphit-conn-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--jp-ui-font-color3);
}

.graphit-conn-dot[data-state='ok'] {
  background: var(--jp-success-color1);
}

.graphit-conn-dot[data-state='mock'] {
  background: var(--jp-warn-color1);
}

.graphit-conn-dot[data-state='error'] {
  background: var(--jp-error-color1);
}

/* ---------- buttons ---------- */

.graphit-btn {
  appearance: none;
  font-family: inherit;
  font-size: var(--jp-ui-font-size1);
  padding: 4px 10px;
  border-radius: var(--graphit-radius);
  border: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  cursor: pointer;
}

.graphit-btn:hover:not(:disabled) {
  background: var(--jp-layout-color3);
}

.graphit-btn:disabled {
  opacity: 0.5;
  cursor: default;
}

.graphit-btn--primary {
  background: var(--jp-brand-color1);
  border-color: var(--jp-brand-color1);
  color: var(--jp-layout-color1);
}

.graphit-btn--primary:hover:not(:disabled) {
  background: var(--jp-brand-color0, var(--jp-brand-color1));
}

/* Armed second step of a two-step action. */
.graphit-btn--warn {
  background: var(--jp-warn-color1);
  border-color: var(--jp-warn-color1);
  color: var(--jp-layout-color1);
  font-weight: 600;
}

.graphit-btn--warn:hover:not(:disabled) {
  background: var(--jp-warn-color0, var(--jp-warn-color1));
}

.graphit-btn--quiet {
  border-color: transparent;
  background: transparent;
  color: var(--jp-ui-font-color2);
}

.graphit-btn--quiet:hover:not(:disabled) {
  background: var(--jp-layout-color2);
}

.graphit-btnrow {
  display: flex;
  gap: var(--graphit-gap);
  flex-wrap: wrap;
  align-items: center;
}

/*
 * "Lernpfad-Empfehlung" card above the tree; more prominent than the legend below it.
 * color-mix keeps the tint readable in both themes.
 */
.graphit-next {
  margin-top: 8px;
  padding: 8px 10px;
  border: 1px solid color-mix(in srgb, var(--jp-brand-color1) 35%, transparent);
  border-radius: 6px;
  background: color-mix(
    in srgb,
    var(--jp-brand-color1) 8%,
    var(--jp-layout-color1)
  );
}

.graphit-next-summary {
  display: flex;
  align-items: baseline;
  gap: 8px;
  cursor: pointer;
}

.graphit-next-title {
  font-weight: 600;
}

.graphit-next-list {
  list-style: none;
  margin: 8px 0 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.graphit-next-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

/* The whole row is clickable. */
.graphit-next-link {
  flex: 1 1 auto;
  min-width: 0;
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 0 8px;
  align-items: baseline;
  padding: 4px 6px;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.graphit-next-link:hover {
  background: color-mix(in srgb, var(--jp-brand-color1) 14%, transparent);
}

.graphit-next-link:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: -2px;
}

.graphit-next-name {
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Second grid row: a long path must not widen the column. */
.graphit-next-path {
  grid-column: 1 / -1;
  color: var(--jp-ui-font-color3);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.graphit-next-reason {
  grid-row: 1;
  grid-column: 2;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  color: var(--jp-ui-font-color2);
  white-space: nowrap;
}

.graphit-next-empty,
.graphit-next-foot {
  margin: 8px 0 0;
}
`,""]),t.d(a,{},{A:p})},287(r,a,t){var o=t(601),e=t.n(o),i=t(314),p=(t.n(i))()(e());p.push([r.id,`/* Quiz panel, question renderers, feedback. */

.graphit-quiz {
  padding: 12px 16px;
  max-width: 780px;
}

.graphit-quiz-header {
  display: flex;
  align-items: baseline;
  gap: var(--graphit-gap);
  flex-wrap: wrap;
  margin-bottom: 12px;
}

.graphit-quiz-header h3 {
  margin: 0;
  font-size: var(--jp-ui-font-size2);
}

.graphit-generating {
  border: 1px solid var(--jp-border-color2);
  border-left: 3px solid var(--jp-brand-color1);
  border-radius: var(--graphit-radius);
  padding: 14px 16px;
  background: var(--jp-layout-color2);
}

.graphit-generating h4 {
  margin: 0 0 6px;
  font-size: var(--jp-ui-font-size2);
}

.graphit-elapsed {
  font-variant-numeric: tabular-nums;
}

.graphit-question {
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius);
  padding: 12px 14px;
  margin-bottom: 12px;
  background: var(--jp-layout-color1);
}

.graphit-question-head {
  display: flex;
  align-items: baseline;
  gap: var(--graphit-gap);
  margin-bottom: 8px;
}

.graphit-question-num {
  font-weight: 600;
  color: var(--jp-ui-font-color2);
  flex: 0 0 auto;
}

.graphit-question-prompt {
  flex: 1 1 auto;
  font-family: var(--jp-content-font-family);
  font-size: var(--jp-content-font-size1);
  line-height: 1.5;
}

.graphit-question-note {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-warn-color1);
  margin-bottom: 8px;
}

.graphit-options {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.graphit-option {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 5px 8px;
  border-radius: var(--graphit-radius);
  cursor: pointer;
  line-height: 1.4;
}

.graphit-option:hover {
  background: var(--jp-layout-color2);
}

.graphit-option input {
  margin: 3px 0 0;
  flex: 0 0 auto;
}

.graphit-cloze-text {
  font-family: var(--jp-content-font-family);
  font-size: var(--jp-content-font-size1);
  line-height: 2.1;
}

.graphit-select {
  font-family: inherit;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--graphit-radius);
  padding: 2px 4px;
  max-width: 100%;
}

/* Open blanks: dashed border. */
.graphit-select[data-empty='true'] {
  border-style: dashed;
}

/* Answered blanks: full-strength text. */
.graphit-select:not([data-empty='true']) {
  color: var(--jp-ui-font-color1);
}

/* Bank entries already used in another blank (reuse: false). */
.graphit-select option:disabled {
  text-decoration: line-through;
  color: var(--jp-ui-font-color3);
}

.graphit-match {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 6px 10px;
  align-items: center;
}

.graphit-match-left {
  font-family: var(--jp-content-font-family);
  line-height: 1.4;
}

.graphit-order-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.graphit-order-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius);
  background: var(--jp-layout-color1);
}

.graphit-order-item[data-dragging='true'] {
  opacity: 0.6;
  border-color: var(--jp-brand-color1);
}

.graphit-order-handle {
  cursor: grab;
  color: var(--jp-ui-font-color3);
  user-select: none;
  touch-action: none;
  flex: 0 0 auto;
  padding: 0 2px;
}

.graphit-order-handle:active {
  cursor: grabbing;
}

.graphit-order-index {
  flex: 0 0 auto;
  width: 18px;
  text-align: right;
  color: var(--jp-ui-font-color3);
  font-variant-numeric: tabular-nums;
}

.graphit-order-text {
  flex: 1 1 auto;
  line-height: 1.4;
}

.graphit-order-buttons {
  flex: 0 0 auto;
  display: flex;
  gap: 2px;
}

.graphit-order-buttons button {
  width: 22px;
  height: 22px;
  padding: 0;
  line-height: 1;
}

.graphit-quiz-footer {
  position: sticky;
  bottom: 0;
  display: flex;
  align-items: center;
  gap: var(--graphit-gap);
  padding: 10px 0;
  background: var(--jp-layout-color1);
  border-top: 1px solid var(--jp-border-color2);
  flex-wrap: wrap;
}

/* Armed submit: the sticky footer shows the warning next to the button. */
.graphit-quiz-footer[data-confirming='true'] {
  border-top-color: var(--jp-warn-color1);
  background: color-mix(in srgb, var(--jp-warn-color1) 10%, var(--jp-layout-color1));
}

.graphit-quiz-warn {
  color: var(--jp-warn-color1);
}

/* ---------- feedback ---------- */

.graphit-result {
  border: 1px solid var(--jp-border-color2);
  border-left-width: 3px;
  border-radius: var(--graphit-radius);
  padding: 10px 12px;
  margin-bottom: 10px;
}

.graphit-result[data-correct='true'] {
  border-left-color: var(--jp-success-color1);
}

.graphit-result[data-correct='false'] {
  border-left-color: var(--jp-error-color1);
}

.graphit-result-head {
  display: flex;
  align-items: center;
  gap: var(--graphit-gap);
  font-weight: 600;
  margin-bottom: 6px;
}

/* ---------- answer review (Feedback.tsx AnswerView) ----------
   data-state: ok (matches), wrong (given but different), missing (should have been
   chosen), empty (nothing given), neutral (irrelevant). */

.graphit-answer {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: 6px;
  margin: 4px 0;
  font-size: var(--jp-ui-font-size1);
}

.graphit-answer--block {
  display: block;
}

.graphit-answer-label {
  display: block;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  color: var(--jp-ui-font-color2);
  margin-bottom: 3px;
}

.graphit-answer--block .graphit-answer-label {
  margin-top: 4px;
}

.graphit-answer-hint {
  font-weight: 400;
}

.graphit-answer-chip {
  display: inline-block;
  padding: 1px 7px;
  border-radius: 10px;
  border: 1px solid var(--graphit-answer-tone, var(--jp-border-color1));
  background: color-mix(in srgb, var(--graphit-answer-tone, var(--jp-layout-color2)) 14%, var(--jp-layout-color1));
  color: var(--jp-ui-font-color1);
  line-height: 1.5;
}

.graphit-result [data-state='ok'] {
  --graphit-answer-tone: var(--jp-success-color1);
}

.graphit-result [data-state='wrong'] {
  --graphit-answer-tone: var(--jp-error-color1);
}

.graphit-result [data-state='missing'] {
  --graphit-answer-tone: var(--jp-warn-color1);
}

.graphit-result [data-state='empty'] .graphit-answer-chip,
.graphit-result .graphit-answer-chip[data-state='empty'] {
  --graphit-answer-tone: var(--jp-border-color1);
  color: var(--jp-ui-font-color2);
  font-style: italic;
}

/* Option / row lists (multiple choice, orphan cloze blanks) */
.graphit-answer-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.graphit-answer-list li {
  display: flex;
  align-items: baseline;
  gap: 8px;
  padding: 3px 8px;
  border-radius: var(--graphit-radius);
  border: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
}

.graphit-answer-list li[data-state='ok'],
.graphit-answer-list li[data-state='wrong'],
.graphit-answer-list li[data-state='missing'] {
  border-color: var(--graphit-answer-tone);
  background: color-mix(in srgb, var(--graphit-answer-tone) 12%, var(--jp-layout-color1));
}

.graphit-answer-list li[data-state='neutral'] {
  color: var(--jp-ui-font-color2);
}

.graphit-answer-mark {
  flex: 0 0 1.2em;
  font-weight: 700;
  color: var(--graphit-answer-tone, var(--jp-ui-font-color3));
}

.graphit-answer-text {
  flex: 1 1 auto;
  min-width: 0;
}

.graphit-answer-note {
  font-size: var(--jp-ui-font-size0);
  color: var(--graphit-answer-tone, var(--jp-ui-font-color2));
  white-space: nowrap;
}

/* Cloze: the sentence with the student's fill-ins as chips */
.graphit-cloze-review {
  margin: 0;
  line-height: 2;
  font-family: var(--jp-content-font-family);
}

.graphit-cloze-slot {
  display: inline-flex;
  gap: 3px;
  margin: 0 2px;
  vertical-align: baseline;
}

/* Matching: one row per left-hand term */
.graphit-answer-table {
  border-collapse: collapse;
  width: 100%;
  font-size: var(--jp-ui-font-size1);
}

.graphit-answer-table th {
  text-align: left;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  color: var(--jp-ui-font-color2);
  padding: 2px 6px;
  border-bottom: 1px solid var(--jp-border-color2);
}

.graphit-answer-table td {
  padding: 4px 6px;
  vertical-align: top;
  border-bottom: 1px solid var(--jp-border-color2);
}

.graphit-answer-table tr:last-child td {
  border-bottom: none;
}

.graphit-answer-table tr[data-state='wrong'] td {
  background: color-mix(in srgb, var(--jp-error-color1) 10%, var(--jp-layout-color1));
}

.graphit-answer-table tr[data-state='ok'] td {
  background: color-mix(in srgb, var(--jp-success-color1) 10%, var(--jp-layout-color1));
}

.graphit-answer-table td.graphit-answer-mark {
  width: 1.2em;
}

/* Ordering: two numbered columns side by side */
.graphit-answer-cols {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 10px;
}

.graphit-answer-order {
  margin: 0;
  padding-left: 1.6em;
}

.graphit-answer-order li {
  padding: 2px 6px;
  margin: 2px 0;
  border-radius: var(--graphit-radius);
}

.graphit-answer-order li[data-state='ok'] {
  background: color-mix(in srgb, var(--jp-success-color1) 12%, var(--jp-layout-color1));
}

.graphit-answer-order li[data-state='wrong'] {
  background: color-mix(in srgb, var(--jp-error-color1) 12%, var(--jp-layout-color1));
}

.graphit-result-expl {
  margin-top: 6px;
  font-family: var(--jp-content-font-family);
  line-height: 1.5;
  color: var(--jp-ui-font-color2);
}

.graphit-result details {
  margin-top: 6px;
  font-size: var(--jp-ui-font-size0);
}

.graphit-result details pre {
  overflow-x: auto;
  background: var(--jp-layout-color2);
  padding: 6px;
  border-radius: 3px;
}

.graphit-scorecard {
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius);
  padding: 12px 14px;
  margin-bottom: 14px;
  background: var(--jp-layout-color2);
}

.graphit-scorecard h4 {
  margin: 0 0 8px;
}
`,""]),t.d(a,{},{A:p})},743(r,a,t){var o=t(601),e=t.n(o),i=t(314),p=(t.n(i))()(e());p.push([r.id,`/* Statistics and review views. */

.graphit-cards {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: var(--graphit-gap);
  margin-bottom: 16px;
}

.graphit-card {
  position: relative; /* anchor for the info mark */
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius);
  padding: 10px 12px;
  background: var(--jp-layout-color2);
}

.graphit-card-value {
  font-size: 22px;
  font-weight: 600;
  line-height: 1.2;
}

.graphit-card-label {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

/* Caption above a row of cards. */
.graphit-cards-title {
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--jp-ui-font-color3);
  margin: 10px 0 4px;
}

/* Info mark in the card's top-right corner; focusable so the tooltip also shows on focus. */
.graphit-info {
  position: absolute;
  top: 5px;
  right: 5px;
  display: block;
  width: 14px;
  height: 14px;
  color: var(--jp-ui-font-color3);
  cursor: help;
  border-radius: 50%;
}

.graphit-info svg {
  display: block;
}

.graphit-info:hover,
.graphit-info:focus-visible {
  border-color: var(--jp-brand-color1);
  color: var(--jp-brand-color1);
  outline: none;
}

.graphit-card[data-status='due_review'] .graphit-card-value {
  color: var(--graphit-status-due);
}

.graphit-card[data-status='mastered'] .graphit-card-value {
  color: var(--graphit-status-mastered);
}

.graphit-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--jp-ui-font-size1);
}

.graphit-table th,
.graphit-table td {
  text-align: left;
  padding: 5px 8px;
  border-bottom: 1px solid var(--jp-border-color2);
  vertical-align: middle;
}

.graphit-table th {
  color: var(--jp-ui-font-color2);
  font-weight: 600;
  font-size: var(--jp-ui-font-size0);
}

.graphit-table td.graphit-num {
  text-align: right;
  font-variant-numeric: tabular-nums;
}

.graphit-table td .graphit-achieve {
  min-width: 90px;
}

/* ---------- review load chart ---------- */

/* One column per day; fixed height keeps renders comparable. */
.graphit-load {
  display: flex;
  align-items: flex-end;
  gap: 3px;
  height: 90px;
  padding: 4px 0 0;
}

.graphit-load-col {
  flex: 1 1 0;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  align-items: center;
  height: 100%;
  gap: 2px;
}

.graphit-load-bar {
  width: 100%;
  min-height: 2px;
  border-radius: 2px 2px 0 0;
  background: var(--jp-brand-color1);
}

/* Overdue column in the due colour. */
.graphit-load-col[data-overdue='true'] .graphit-load-bar {
  background: var(--graphit-status-due);
}

/* Empty days keep a hairline. */
.graphit-load-bar[style*='height: 0'] {
  background: var(--jp-layout-color3);
}

/* Sidebar version: lower, no counts. */
.graphit-load--mini {
  height: 32px;
  gap: 2px;
  padding: 0;
}

/* Gap separates the overdue column in the mini version. */
.graphit-load--mini .graphit-load-col[data-overdue='true'] {
  margin-right: 5px;
}

.graphit-load-mini-axis {
  position: relative;
  height: 1.3em;
  margin-top: 2px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
}

.graphit-load-mini-axis span {
  position: absolute;
  top: 0;
  transform: translateX(-50%);
  white-space: nowrap;
}

/* Short tick above each axis label. */
.graphit-load-mini-axis span::before {
  content: '';
  position: absolute;
  left: 50%;
  top: -3px;
  width: 1px;
  height: 3px;
  background: var(--jp-ui-font-color3);
}

.graphit-load-count {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  font-variant-numeric: tabular-nums;
  line-height: 1;
  min-height: 1em;
}

/*
 * Three equal cells (not space-between), so the middle label sits exactly at 50 %,
 * under the day-7 column.
 */
.graphit-load-axis {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
  margin: 2px 0 8px;
}

.graphit-load-axis span:nth-child(2) {
  text-align: center;
}

.graphit-load-axis span:last-child {
  text-align: right;
}

.graphit-legend {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  margin: 6px 0 12px;
}

.graphit-legend span {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

/* ---------- review ---------- */

/* Room for the sticky action bar. */
.graphit-review {
  padding-bottom: 0;
}

/* Headline card with the due count. */
.graphit-review-hero {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding: 12px 14px;
  margin-bottom: 14px;
  border: 1px solid var(--jp-border-color2);
  border-left: 3px solid var(--graphit-status-due);
  border-radius: var(--graphit-radius);
  background: var(--jp-layout-color2);
}

.graphit-review-headline {
  display: flex;
  align-items: baseline;
  gap: 10px;
}

.graphit-review-count {
  font-size: 40px;
  font-weight: 600;
  line-height: 1;
  color: var(--graphit-status-due);
}

.graphit-review-count[data-zero='true'] {
  color: var(--jp-ui-font-color3);
}

.graphit-review-label {
  font-size: var(--jp-ui-font-size1);
}

.graphit-review-open {
  text-align: right;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color3);
}

.graphit-review-open-value {
  font-weight: 600;
  color: var(--jp-ui-font-color2);
}

.graphit-review-intro {
  margin-top: 0;
}

/* Selection summary plus the two shortcuts. */
.graphit-review-listhead {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--graphit-gap);
  margin-bottom: 4px;
}

.graphit-review-actions {
  display: flex;
  gap: 12px;
}

.graphit-checklist {
  list-style: none;
  margin: 0;
  padding: 0;
}

.graphit-review-list {
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius);
  overflow: hidden;
}

.graphit-checklist li {
  display: flex;
  align-items: center;
  gap: var(--graphit-gap);
  padding: 5px 4px;
  border-bottom: 1px solid var(--jp-border-color2);
}

.graphit-review-list li {
  padding: 7px 10px;
  /* Transparent by default so rows do not shift when the accent appears. */
  border-left: 3px solid transparent;
}

.graphit-review-list li:hover {
  background: var(--jp-layout-color2);
}

/* Row accent: solid = due now, faint = due within the week. */
.graphit-review-list li[data-overdue='true'] {
  border-left-color: var(--graphit-status-due);
}

.graphit-review-list li[data-overdue='false'] {
  border-left-color: var(--jp-border-color1);
}

.graphit-checklist li:last-child {
  border-bottom: none;
}

.graphit-checklist-name {
  flex: 1 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Fixed width so the bars line up. */
.graphit-review-bar {
  flex: 0 0 90px;
  display: block;
}

/* Sticky action bar at the bottom of the scroll container. */
.graphit-review-actionbar {
  position: sticky;
  bottom: 0;
  display: flex;
  align-items: center;
  gap: var(--graphit-gap);
  flex-wrap: wrap;
  /* Negative margins let the opaque background span the full width. */
  margin: 12px -16px 0;
  padding: 10px 16px;
  border-top: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
}

/* ---------- combined quiz ---------- */

/* Progress bar shown while all concept quizzes are generated up front. */
.graphit-batch-progress {
  height: 8px;
  border-radius: 4px;
  background: var(--jp-layout-color3);
  overflow: hidden;
  margin: 10px 0 4px;
}

.graphit-batch-progress-fill {
  height: 100%;
  background: var(--jp-brand-color1);
  transition: width 0.3s ease;
}

.graphit-batch-genlist {
  list-style: none;
  margin: 8px 0 0;
  padding: 0;
}

.graphit-batch-genlist li {
  display: flex;
  align-items: baseline;
  gap: 8px;
  padding: 2px 0;
  color: var(--jp-ui-font-color2);
}

.graphit-batch-genlist li[data-state='active'] {
  color: var(--jp-ui-font-color1);
  font-weight: 600;
}

.graphit-batch-genlist li[data-state='pending'] {
  color: var(--jp-ui-font-color3);
}

.graphit-batch-genlist-mark {
  flex: 0 0 auto;
  width: 1em;
  text-align: center;
}

.graphit-batch-genlist li[data-state='done'] .graphit-batch-genlist-mark {
  color: var(--jp-success-color1);
}

.graphit-batch-genlist li[data-state='failed'] .graphit-batch-genlist-mark {
  color: var(--jp-error-color1);
}

/* Two columns: questions on the left, a sticky question map on the right. */
.graphit-batch {
  display: flex;
  align-items: flex-start;
  gap: 20px;
}

.graphit-batch-main {
  flex: 1 1 auto;
  min-width: 0;
}

.graphit-batch-concept {
  margin-top: 18px;
  padding-top: 8px;
  border-top: 1px solid var(--jp-border-color2);
}

.graphit-batch-concept-title {
  margin: 0 0 8px;
  font-size: var(--jp-ui-font-size2);
}

/* Sticky map. Boxes carry the global question number and jump to it on click. */
.graphit-batch-map {
  flex: 0 0 172px;
  position: sticky;
  top: 0;
  align-self: flex-start;
  padding: 10px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius);
  background: var(--jp-layout-color2);
}

.graphit-batch-map-title {
  font-weight: 600;
  margin-bottom: 8px;
}

.graphit-batch-map-group {
  margin-bottom: 10px;
}

.graphit-batch-map-concept {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.graphit-batch-map-boxes {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.graphit-batch-map-box {
  appearance: none;
  width: 26px;
  height: 26px;
  padding: 0;
  border-radius: var(--graphit-radius);
  border: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: inherit;
  font-size: var(--jp-ui-font-size0);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.graphit-batch-map-box:hover {
  border-color: var(--jp-brand-color1);
}

.graphit-batch-map-box[data-answered='true'] {
  background: var(--jp-brand-color1);
  border-color: var(--jp-brand-color1);
  color: var(--jp-layout-color1);
}

.graphit-batch-map-box[data-kind='failed'] {
  background: var(--jp-layout-color1);
  border-style: dashed;
  color: var(--jp-error-color1);
  cursor: default;
}

/* Evaluation overview: green when the question was right, red when wrong. */
.graphit-batch-map-box[data-correct='true'] {
  background: var(--jp-success-color1);
  border-color: var(--jp-success-color1);
  color: var(--jp-layout-color1);
}

.graphit-batch-map-box[data-correct='false'] {
  background: var(--jp-error-color1);
  border-color: var(--jp-error-color1);
  color: var(--jp-layout-color1);
}

.graphit-batch-map-legend {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--jp-border-color2);
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.graphit-batch-map-legend span {
  display: flex;
  align-items: center;
  gap: 6px;
}

/* The legend swatches are decorative, not clickable, and sized down a touch. */
.graphit-batch-map-legend .graphit-batch-map-box {
  width: 16px;
  height: 16px;
  cursor: default;
}

/* Scroll offset so the heading stays visible when jumping to a question. */
.graphit-batch-main [id^='graphit-bq-q-'] {
  scroll-margin-top: 12px;
}

/* Evaluation overview map: full width, wraps, boxes jump to the concept card. */
.graphit-batch-summary-map {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  padding: 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius);
  background: var(--jp-layout-color2);
  margin-bottom: 10px;
}

.graphit-batch-summary-map .graphit-batch-map-boxes {
  flex-basis: 100%;
}

/* Full-width row inside the grey overview box, below the concept boxes. */
.graphit-batch-summary-legend {
  flex-basis: 100%;
  display: flex;
  gap: 16px;
  margin-top: 4px;
  padding-top: 10px;
  border-top: 1px solid var(--jp-border-color2);
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.graphit-batch-summary-legend span {
  display: flex;
  align-items: center;
  gap: 6px;
}

.graphit-batch-summary-legend .graphit-batch-map-box {
  width: 16px;
  height: 16px;
  cursor: default;
}

/* Scroll offset when the overview jumps to a concept's result card. */
[id^='graphit-bq-result-'] {
  scroll-margin-top: 12px;
}

/* Feedback: one card per concept, details collapsed by default. */
.graphit-batch-concept-result {
  margin-top: 12px;
}

.graphit-batch-concept-score {
  margin-bottom: 0;
}

.graphit-batch-concept-details > summary {
  cursor: pointer;
  color: var(--jp-ui-font-color2);
  padding: 6px 0;
}

@media (width <= 800px) {
  .graphit-batch {
    flex-direction: column;
  }

  .graphit-batch-map {
    position: static;
    width: 100%;
    flex-basis: auto;
    order: -1;
  }
}

/*
 * Heading above the progress bar; its own class (not \`.graphit-meter-label\`) so it
 * aligns with the neighbouring h3.
 */
.graphit-meter-head {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  gap: 8px;
  margin: 16px 0 6px;
}

.graphit-meter-head > h4 {
  margin: 0;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.graphit-meter-head > span {
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color2);
}
`,""]),t.d(a,{},{A:p})},382(r,a,t){var o=t(601),e=t.n(o),i=t(314),p=(t.n(i))()(e());p.push([r.id,`/*
 * Guided tour: offer dialog and spotlight.
 *
 * Rendered into document.body (outside .graphit-root), so all styles are declared here.
 * The dimming is the ring's outward shadow, leaving the highlighted region untouched.
 */

.graphit-tour {
  position: fixed;
  inset: 0;
  z-index: 10001;
  /* The layer itself passes events through; the backdrop opts back in. */
  pointer-events: none;
  font-family: var(--jp-ui-font-family);
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color1);
}

.graphit-tour *,
.graphit-tour *::before,
.graphit-tour *::after {
  box-sizing: border-box;
}

/* Catches clicks so the interface underneath cannot be operated. */
.graphit-tour-backdrop {
  position: absolute;
  inset: 0;
  pointer-events: auto;
}

/* Without a highlighted region, the backdrop dims the screen itself. */
.graphit-tour-backdrop[data-spotlight='no'] {
  background: var(--jp-dialog-background, rgba(0, 0, 0, 0.5));
}

.graphit-tour-ring {
  position: fixed;
  pointer-events: none;
  border: 2px solid var(--jp-brand-color1);
  border-radius: var(--graphit-radius, 4px);
  box-shadow: 0 0 0 9999px var(--jp-dialog-background, rgba(0, 0, 0, 0.5));
  transition:
    top 140ms ease,
    left 140ms ease,
    width 140ms ease,
    height 140ms ease;
}

@media (prefers-reduced-motion: reduce) {
  .graphit-tour-ring {
    transition: none;
  }
}

/* ----------------------------------------------------------------- Card */

.graphit-tour-card {
  position: fixed;
  width: 360px;
  max-width: calc(100vw - 28px);
  max-height: calc(100vh - 28px);
  overflow-y: auto;
  pointer-events: auto;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--graphit-radius, 4px);
  box-shadow: var(--jp-elevation-z8, 0 6px 20px rgba(0, 0, 0, 0.3));
  padding: 16px 18px 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.graphit-tour-card:focus {
  outline: none;
}

.graphit-tour-card--center {
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.graphit-tour-card h2 {
  margin: 0;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  line-height: 1.3;
}

.graphit-tour-card p {
  margin: 0;
  line-height: 1.55;
  color: var(--jp-ui-font-color1);
}

.graphit-tour-header {
  display: flex;
  align-items: center;
  gap: 8px;
}

.graphit-tour-counter {
  flex: 1 1 auto;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
  letter-spacing: 0.04em;
}

.graphit-tour-close {
  flex: 0 0 auto;
  border: none;
  background: transparent;
  color: var(--jp-ui-font-color2);
  font-size: 18px;
  line-height: 1;
  padding: 2px 6px;
  cursor: pointer;
  border-radius: 3px;
}

.graphit-tour-close:hover {
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.graphit-tour-footnote {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
}

/* ------------------------------------------------------------- Progress */

.graphit-tour-dots {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  padding: 2px 0;
}

.graphit-tour-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--jp-border-color1);
}

.graphit-tour-dot[data-active='true'] {
  background: var(--jp-brand-color1);
}

/* -------------------------------------------------------------- Buttons */

.graphit-tour-buttons {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  padding-top: 2px;
}

.graphit-tour-spacer {
  flex: 1 1 auto;
}

.graphit-tour-remember {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color2);
}

.graphit-tour-remember input {
  margin: 0;
  cursor: pointer;
}

/* ------------------------------------------------- Button in the guide */

.graphit-guide-tour {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  padding: 10px 12px;
  margin: 4px 0 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--graphit-radius, 4px);
  background: var(--jp-layout-color2);
}

.graphit-guide-tour p {
  flex: 1 1 16rem;
  margin: 0;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color2);
}
`,""]),t.d(a,{},{A:p})},884(r,a,t){var o=t(601),e=t.n(o),i=t(314),p=(t.n(i))()(e());p.push([r.id,`/* Domain tree and node detail panel. */

.graphit-tree {
  flex: 1 1 auto;
  min-height: 0;
  overflow: auto;
  padding: 4px 0;
}

.graphit-tree-row {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  min-height: 24px;
  padding: 2px 8px 2px 0;
  border: none;
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.graphit-tree-row:hover {
  background: var(--jp-layout-color2);
}

/* Mixed from the brand colour and the page background, since --jp-brand-color3 does
   not change in the dark theme. */
.graphit-tree-row[aria-selected='true'] {
  background: color-mix(in srgb, var(--jp-brand-color1) 22%, var(--jp-layout-color1));
}

.graphit-tree-row:focus-visible {
  outline: 1px solid var(--jp-brand-color1);
  outline-offset: -1px;
}

.graphit-tree-chevron {
  flex: 0 0 auto;
  width: 14px;
  text-align: center;
  color: var(--jp-ui-font-color2);
  user-select: none;
}

.graphit-tree-name {
  flex: 1 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.graphit-tree-row[data-type='lecture'] .graphit-tree-name,
.graphit-tree-row[data-type='chapter'] .graphit-tree-name {
  font-weight: 600;
}

.graphit-tree-row[data-empty='true'] .graphit-tree-name {
  color: var(--jp-ui-font-color3);
  font-style: italic;
}

.graphit-tree-meta {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 6px;
}

.graphit-tree-meta .graphit-bar,
.graphit-tree-meta .graphit-achieve {
  width: 52px;
}

.graphit-tree-visits {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
  display: inline-flex;
  align-items: center;
  gap: 2px;
}

.graphit-lock {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
}

.graphit-lock[data-open='true'] {
  color: var(--graphit-status-mastered);
}

.graphit-due-chip {
  font-size: var(--jp-ui-font-size0);
  padding: 0 4px;
  border-radius: 3px;
  color: var(--graphit-status-due);
  border: 1px solid var(--graphit-status-due);
}

.graphit-due-chip[data-overdue='true'] {
  background: var(--graphit-status-due);
  color: var(--jp-layout-color1);
}

/* ---------- detail panel ---------- */

.graphit-detail {
  padding: 12px 16px;
}

.graphit-detail h3 {
  margin: 0 0 2px;
  font-size: var(--jp-ui-font-size2);
}

.graphit-detail-path {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color3);
  margin-bottom: 10px;
  word-break: break-all;
}

.graphit-meter {
  margin: 8px 0;
}

/* Heading above the mastery bar, whose top margin holds the peak caption. */
.graphit-meter-title {
  margin: 16px 0 0;
}

/* Dismissible note under the mastery score, shown after a quiz. */
.graphit-hint {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin-top: 8px;
  padding: 6px 8px;
  border-radius: 6px;
  /* --jp-warn-color3 does not change in the dark theme, hence color-mix. */
  background: color-mix(in srgb, var(--jp-warn-color1) 16%, var(--jp-layout-color1));
  border: 1px solid var(--jp-warn-color1);
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color1);
}

.graphit-hint-text {
  flex: 1 1 auto;
  line-height: 1.4;
}

.graphit-hint-close {
  flex: 0 0 auto;
  margin: -2px -2px 0 0;
  padding: 0 4px;
  border: none;
  background: transparent;
  color: var(--jp-ui-font-color2);
  font-size: 15px;
  line-height: 1.2;
  cursor: pointer;
  border-radius: 4px;
}

.graphit-hint-close:hover {
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.graphit-meter-label {
  display: flex;
  justify-content: space-between;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  margin-bottom: 3px;
}


.graphit-facts {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 3px 12px;
  font-size: var(--jp-ui-font-size1);
  margin: 10px 0;
}

.graphit-facts dt {
  color: var(--jp-ui-font-color2);
}

.graphit-facts dd {
  margin: 0;
}

.graphit-reclist {
  list-style: none;
  margin: 4px 0 0;
  padding: 0;
}

.graphit-reclist li {
  padding: 4px 0;
  border-bottom: 1px solid var(--jp-border-color2);
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}

.graphit-reclist li:last-child {
  border-bottom: none;
}

.graphit-link {
  appearance: none;
  border: none;
  background: none;
  padding: 0;
  font: inherit;
  color: var(--jp-brand-color1);
  cursor: pointer;
  text-align: left;
}

.graphit-link:hover {
  text-decoration: underline;
}

/* ---------- learning path ----------
   Nested tinted boxes (path > category > group > entry) instead of separator lines.
   Tints are mixed from status colours so they work in the dark theme. */

.graphit-path {
  border: 1px solid var(--jp-border-color1);
  border-radius: 6px;
  padding: 10px 12px 12px;
  background: var(--jp-layout-color2);
}

.graphit-path > h3 {
  margin: 0 0 8px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
}

/* Two categories side by side, one column when narrow. */
.graphit-path-cats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 10px;
  margin-top: 10px;
}

.graphit-path-cat {
  min-width: 0;
  border: 1px solid var(--graphit-path-tone);
  border-left-width: 4px;
  border-radius: var(--graphit-radius);
  padding: 8px 10px 10px;
  background: color-mix(in srgb, var(--graphit-path-tone) 9%, var(--jp-layout-color1));
}

.graphit-path-cat[data-kind='required'] {
  --graphit-path-tone: var(--graphit-status-inprogress);
}

.graphit-path-cat[data-kind='helpful'] {
  --graphit-path-tone: var(--graphit-status-visited);
}

.graphit-path-cat > h4 {
  margin: 0;
  font-size: var(--jp-ui-font-size1);
  font-weight: 700;
  /* Mixed towards the text colour for more contrast in both themes. */
  color: color-mix(in srgb, var(--graphit-path-tone) 78%, var(--jp-ui-font-color1));
}

.graphit-path-cat > h4 > span,
.graphit-path-group-title > span {
  font-weight: 400;
  color: var(--jp-ui-font-color2);
}

.graphit-path-caption {
  margin: 2px 0 6px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.graphit-path-empty {
  margin: 0;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

/* Sub-boxes inside a category; each carries its own tone. */
.graphit-path-group {
  border: 1px solid var(--graphit-path-tone);
  border-radius: var(--graphit-radius);
  padding: 6px 8px 8px;
  margin-top: 8px;
  background: color-mix(in srgb, var(--graphit-path-tone) 14%, var(--jp-layout-color1));
}

.graphit-path-group[data-kind='open'] {
  --graphit-path-tone: var(--graphit-status-mastered);
}

.graphit-path-group[data-kind='waiting'] {
  --graphit-path-tone: var(--jp-error-color1);
}

.graphit-path-group[data-kind='refresh'] {
  --graphit-path-tone: var(--graphit-status-due);
}

.graphit-path-group-title {
  font-size: var(--jp-ui-font-size1);
  font-weight: 700;
  color: color-mix(in srgb, var(--graphit-path-tone) 78%, var(--jp-ui-font-color1));
}

/* Entries as small cards. */
.graphit-path-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.graphit-path-list li {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
  padding: 4px 8px;
  border-radius: var(--graphit-radius);
  border: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
}

.graphit-path-list .graphit-link {
  flex: 1 1 auto;
  min-width: 0;
}
`,""]),t.d(a,{},{A:p})},314(r){r.exports=function(r){var a=[];return a.toString=function(){return this.map(function(a){var t="",o=void 0!==a[5];return a[4]&&(t+="@supports (".concat(a[4],") {")),a[2]&&(t+="@media ".concat(a[2]," {")),o&&(t+="@layer".concat(a[5].length>0?" ".concat(a[5]):""," {")),t+=r(a),o&&(t+="}"),a[2]&&(t+="}"),a[4]&&(t+="}"),t}).join("")},a.i=function(r,t,o,e,i){"string"==typeof r&&(r=[[null,r,void 0]]);var p={};if(o)for(var n=0;n<this.length;n++){var l=this[n][0];null!=l&&(p[l]=!0)}for(var s=0;s<r.length;s++){var d=[].concat(r[s]);o&&p[d[0]]||(void 0!==i&&(void 0===d[5]||(d[1]="@layer".concat(d[5].length>0?" ".concat(d[5]):""," {").concat(d[1],"}")),d[5]=i),t&&(d[2]&&(d[1]="@media ".concat(d[2]," {").concat(d[1],"}")),d[2]=t),e&&(d[4]?(d[1]="@supports (".concat(d[4],") {").concat(d[1],"}"),d[4]=e):d[4]="".concat(e)),a.push(d))}},a}},601(r){r.exports=function(r){return r[1]}},72(r){var a=[];function t(r){for(var t=-1,o=0;o<a.length;o++)if(a[o].identifier===r){t=o;break}return t}function o(r,o){for(var e={},i=[],p=0;p<r.length;p++){var n=r[p],l=o.base?n[0]+o.base:n[0],s=e[l]||0,d="".concat(l," ").concat(s);e[l]=s+1;var g=t(d),h={css:n[1],media:n[2],sourceMap:n[3],supports:n[4],layer:n[5]};if(-1!==g)a[g].references++,a[g].updater(h);else{var c=function(r,a){var t=a.domAPI(a);return t.update(r),function(a){a?(a.css!==r.css||a.media!==r.media||a.sourceMap!==r.sourceMap||a.supports!==r.supports||a.layer!==r.layer)&&t.update(r=a):t.remove()}}(h,o);o.byIndex=p,a.splice(p,0,{identifier:d,updater:c,references:1})}i.push(d)}return i}r.exports=function(r,e){var i=o(r=r||[],e=e||{});return function(r){r=r||[];for(var p=0;p<i.length;p++){var n=t(i[p]);a[n].references--}for(var l=o(r,e),s=0;s<i.length;s++){var d=t(i[s]);0===a[d].references&&(a[d].updater(),a.splice(d,1))}i=l}}},659(r){var a={};r.exports=function(r,t){var o=function(r){if(void 0===a[r]){var t=document.querySelector(r);if(window.HTMLIFrameElement&&t instanceof window.HTMLIFrameElement)try{t=t.contentDocument.head}catch(r){t=null}a[r]=t}return a[r]}(r);if(!o)throw Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");o.appendChild(t)}},540(r){r.exports=function(r){var a=document.createElement("style");return r.setAttributes(a,r.attributes),r.insert(a,r.options),a}},56(r,a,t){r.exports=function(r){var a=t.nc;a&&r.setAttribute("nonce",a)}},825(r){r.exports=function(r){if("u"<typeof document)return{update:function(){},remove:function(){}};var a=r.insertStyleElement(r);return{update:function(t){var o,e,i;o="",t.supports&&(o+="@supports (".concat(t.supports,") {")),t.media&&(o+="@media ".concat(t.media," {")),(e=void 0!==t.layer)&&(o+="@layer".concat(t.layer.length>0?" ".concat(t.layer):""," {")),o+=t.css,e&&(o+="}"),t.media&&(o+="}"),t.supports&&(o+="}"),(i=t.sourceMap)&&"u">typeof btoa&&(o+="\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(i))))," */")),r.styleTagTransform(o,a,r.options)},remove:function(){var r;null===(r=a).parentNode||r.parentNode.removeChild(r)}}}},113(r){r.exports=function(r,a){if(a.styleSheet)a.styleSheet.cssText=r;else{for(;a.firstChild;)a.removeChild(a.firstChild);a.appendChild(document.createTextNode(r))}}},579(r,a,t){var o=t(72),e=t.n(o),i=t(825),p=t.n(i),n=t(659),l=t.n(n),s=t(56),d=t.n(s),g=t(540),h=t.n(g),c=t(113),u=t.n(c),x=t(475),b={};b.styleTagTransform=u(),b.setAttributes=d(),b.insert=l().bind(null,"head"),b.domAPI=p(),b.insertStyleElement=h(),e()(x.A,b),x.A&&x.A.locals&&x.A.locals}}]);